"""Collect only the dispatched experiments; PR checks are handled by PR watching."""
import concurrent.futures
import datetime
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
dispatches = json.loads((ROOT / 'dispatches.json').read_text())
previous = {}
downloaded = set()

def observe(record):
    run_id = int(record['dispatch_output'].rstrip('/').rsplit('/', 1)[1])
    data = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run_id), '--json', 'databaseId,headSha,status,conclusion,displayTitle,url,createdAt,updatedAt,jobs'], text=True))
    assert data['headSha'] == record['runtime_commit'], (run_id, data['headSha'])
    data.update(mode=record['mode'], body_mib=record['body_mib'], architecture=record['architecture'])
    return data

while True:
    with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:
        records = list(pool.map(observe, dispatches))
    temporary = ROOT / 'workflows.tmp.json'
    temporary.write_text(json.dumps(records, indent=2) + '\n')
    temporary.replace(ROOT / 'workflows.json')
    for record in records:
        run_id = record['databaseId']
        signature = (record['status'], record['conclusion'])
        if previous.get(run_id) != signature:
            print(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(), run=run_id, body_mib=record['body_mib'], mode=record['mode'], status=record['status'], conclusion=record['conclusion'])), flush=True)
            previous[run_id] = signature
        if record['status'] == 'completed' and run_id not in downloaded:
            destination = ROOT / (record['mode'] + '-' + str(record['body_mib']))
            if record['conclusion'] != 'success':
                destination = ROOT / ('failed-' + str(run_id))
            destination.mkdir(exist_ok=True)
            result = subprocess.run(['gh', 'run', 'download', str(run_id), '--dir', str(destination)], text=True, capture_output=True)
            (destination / 'download-status.json').write_text(json.dumps(dict(exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr), indent=2) + '\n')
            if result.returncode == 0:
                downloaded.add(run_id)
                print(json.dumps(dict(downloaded=run_id, path=str(destination))), flush=True)
            else:
                print(json.dumps(dict(download_failed=run_id, stderr=result.stderr)), flush=True)
    if all(r['status'] == 'completed' for r in records):
        print(json.dumps(dict(finished=True, successful=sum(r['conclusion'] == 'success' for r in records), total=len(records), downloaded=len(downloaded))), flush=True)
        break
    time.sleep(30)
