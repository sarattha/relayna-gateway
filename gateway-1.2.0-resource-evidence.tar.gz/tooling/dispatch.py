import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
plan = json.loads((ROOT / 'release-plan.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == plan['runtime_commit']
remote = subprocess.check_output(['git', 'ls-remote', 'origin', 'refs/heads/' + plan['branch']], text=True).split()[0]
assert remote == plan['runtime_commit'], (remote, plan['runtime_commit'])
path = ROOT / 'dispatches.json'
assert not path.exists(), 'Do not duplicate existing dispatches'
dispatches = []
path.write_text(json.dumps(dispatches, indent=2) + '\n')
for mode, size in [('full', size) for size in plan['full_sizes_mib']] + [('comparison', 5)]:
    record = dict(mode=mode, body_mib=size, architecture=plan['architecture'], runtime_commit=plan['runtime_commit'], started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    args = ['gh', 'workflow', 'run', 'body-admission-benchmark.yml', '--ref', plan['branch'], '-f', 'architecture=' + plan['architecture'], '-f', 'mode=' + mode, '-f', 'body_mib=' + str(size)]
    if mode == 'comparison':
        args += ['-f', 'baseline_image=' + plan['baseline_image']]
    result = subprocess.run(args, text=True, capture_output=True, check=True)
    record['dispatch_output'] = result.stdout.strip()
    dispatches.append(record)
    path.write_text(json.dumps(dispatches, indent=2) + '\n')
    print(json.dumps(record), flush=True)
