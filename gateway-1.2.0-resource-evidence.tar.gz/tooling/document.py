"""Generate versioned release prose from the audited measurements."""
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
repo = root.parents[2]
audit = json.loads((root / 'public/gateway-1.2.0-audit.json').read_text())
archive_commit = sys.argv[1]
assert len(archive_commit) == 40
base = 'https://sarattha.github.io/relayna-gateway/assets/releases/v1.2.0/'
prefix = 'gateway-1.2.0-'
source = audit['runtime_commit']

def f(x):
    return 'missing' if x is None else f'{x:.2f}'

def span(values):
    values = list(values)
    return str(min(values)) if min(values) == max(values) else f'{min(values)}–{max(values)}'

def timing(d, divisor=1000):
    return ' / '.join(f(d.get(k) / divisor) if d.get(k) is not None else 'missing' for k in ['p50', 'p95', 'p99'])

def link(suffix, text):
    return f'[{text}]({base}{prefix}{suffix})'

lines = [f'''# v1.2.0 release benchmark

Status: **measurement and evidence audit complete**. Fresh validation measured
runtime `{source}` on 6 November 2026 (UTC). Final-head CI and GitHub merge gates
still apply. Later documentation and test-scheduling commits do not change the measured runtime inputs.

The six adaptive searches completed **{audit['totals']['trials']} fresh-pod trials**,
with at least three resource-stable confirmations at each selected setting.
Resource stability permits separately reported lost admission replies when every
request reconciles to a verified success or a server-side admission denial.
It does not imply HTTP-clean delivery, a latency SLO or a safe production setting.

## Runtime, harness and conditions

- Runtime and harness: [{source[:12]}](https://github.com/sarattha/relayna-gateway/commit/{source}), clean checkout; Cargo version 1.2.0. The source-built images label the revision but their version label is `unknown`. They are distinct from the signed image subsequently built for the release tag.
- Native Linux **amd64** for host, Docker, image and kind nodes, without emulation. Each size uses a separate Ubuntu 24.04 runner; CPU models and Docker resources are recorded below. Separate runners are not a matched hardware cohort.
- Two Gateway pods, each **2 CPUs / 1 GiB memory / 512 MiB serialized-body budget**, real PostgreSQL/Redis, direct pod endpoints and the production Distroless image. External digest-pinned BusyBox sampler tools are mounted only in benchmark pods, with centisecond timestamps and nominal 250 ms sampling. Cgroup peaks and sampled process RSS measure different things.
- Standard fixed body-slot mode with adaptive configuration search, not opt-in elastic/working-memory admission. Authentication/source controls remain enabled. Early denials can prevent body slots filling; configured ceilings are not occupied concurrency.
- Exact JSON sizes 5, 10, 20, 40, 80 and 100 MiB; at least three fresh-pod confirmations; finite search ceiling 4,096 configured slots/pod. Actual offered cohorts and occupied body counts are retained for each trial.
- The upstream pauses reads for ten seconds and waits two seconds after upload before replying. Client, condition and outer trial deadlines are 180, 300 and 600 seconds. Successful latency includes upload, scheduling and these deliberate delays; it is not isolated Gateway overhead.
- No production credentials, prompts or OpenAI calls. Bootstrap tokens and registered-service credentials are generated for the isolated experiment and excluded from exported evidence.

Each full workflow used the equivalent of:

```sh
scripts/bench-body-admission --json doctor
scripts/bench-body-admission --json run --build \\
  --body-mib <5|10|20|40|80|100> --repetitions 3 \\
  --output target/body-capacity
```

### Per-size provenance

| JSON MiB | CPU model | Docker CPUs / memory bytes | Initial → final offered/pod | Trials | Workflow |
| --- | --- | ---: | ---: | ---: | --- |''']
for s in audit['sizes']:
    p=s['provenance']['preflight']; docker=p['docker']
    lines.append(f"| {s['body_mib']} | {p['host'].get('cpu_model') or 'unavailable'} | {docker['NCPU']} / {docker['MemTotal']} | {s['initial_cohort_per_pod']} → {s['cohort_per_pod']} | {s['total_trials']} | [run {s['workflow_id']}](https://github.com/sarattha/relayna-gateway/actions/runs/{s['workflow_id']}) |")
lines += ['\n| JSON MiB | Resolved native image ID |', '| --- | --- |']
for s in audit['sizes']:
    lines.append(f"| {s['body_mib']} | `{s['provenance']['image']['id']}` |")
lines += ['\nThe exact harness source, per-file SHA-256 hashes, kernel/Docker versions, node identities, image IDs and sampler identity are retained in the audit and raw archives. Builds finish before measurement. Owned clusters are deleted afterward.\n', '''## Repeated resource observations

Memory is the largest individual-pod observation across selected confirmations.
Headroom is 1,024 MiB minus observed cgroup peak. Selected trials have no OOMs,
restarts or censored memory; reservations drain to zero and admission counters
reconcile. HTTP-clean counts and transport errors remain explicit below.

| JSON MiB | Selected slots/pod | Stable / HTTP-clean trials | Peak occupied bodies/pod | Interpretation | Adjacent OOM trials | Peak RSS / cgroup MiB | Headroom MiB |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: |''']
for s in audit['sizes']:
    adjacent = f"{s['adjacent_slots']}: {s['adjacent_oom_trials']}/{s['adjacent_trials']}" if s['adjacent_slots'] is not None else 'not observed'
    lines.append(f"| {s['body_mib']} | {s['slots']} | {s['stable_trials']} / {s['http_clean_trials']} | {s['buffered_requests_peak']} | {s['label']} | {adjacent} | {f(s['rss_peak_mib'])} / {f(s['cgroup_peak_mib'])} | {f(s['headroom_mib'])} |")
lines += ['''
The audited edge label requires OOM in **every** repeated adjacent trial and no
failure at a lower tested slot count. Intermittent adjacent OOMs or a finite
ceiling remain tested lower bounds. Settings selected from repeated trials take
precedence over higher one-off discoveries. Do not interpret high configured
ceilings with lower occupied-body counts as maximum body concurrency.

These resource boundaries require production headroom. Serialized bytes exclude
parsing, connection state and other process allocations. Keep the released defaults
of eight slots and 512 MiB unless deployment-specific evidence supports tuning.

## Timing and outcomes

Latency columns are the worst per-trial percentiles, in seconds, not pooled
percentiles. Elapsed is the longest batch. Outcome ranges span both pods per
trial. All HTTP 200 bodies are verified. Denials use the expected body/authentication
503 or source-limit 429 error code.

| JSON MiB | Success p50 / p95 / p99 s | Rejection p50 / p95 / p99 s | Elapsed s | Verified 200/trial | 429 / 503 per trial | Transport errors/trial | OOM / restarts |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |''']
for s in audit['sizes']:
    rows=s['selected_trials']
    lines.append(f"| {s['body_mib']} | {timing(s['success_latency_worst_ms'])} | {timing(s['rejection_latency_worst_ms'])} | {f(s['elapsed_max_ms']/1000)} | {span(r['successes'] for r in rows)} | {span(r['statuses'].get('429',0) for r in rows)} / {span(r['statuses'].get('503',0) for r in rows)} | {span(r['transport_errors'] for r in rows)} | 0 / 0 |")
lines += ['\n| JSON MiB | Server source denials/trial | Server authentication denials/trial | Body slot / byte denials/trial |', '| --- | ---: | ---: | ---: |']
for s in audit['sizes']:
    r=s['selected_trials']
    lines.append(f"| {s['body_mib']} | {span(x['source_denials'] for x in r)} | {span(x['authentication_denials'] for x in r)} | {span(x['concurrency_denials'] for x in r)} / {span(x['byte_denials'] for x in r)} |")
t=audit['totals']
lines += [f'''
Across all **{t['trials']} exploration and confirmation trials**: {t['successes']:,}
verified successes, {t['http_429']:,} HTTP 429s, {t['http_503']:,} HTTP 503s and
{t['transport_errors']:,} transport errors. There were {t['resource_stable_trials']}
resource-stable trials, {t['http_clean_trials']} HTTP-clean trials, {t['oom_trials']}
OOM trials, {t['oom_pods']} OOM pod observations and {t['restarts']} restarts.
These totals include deliberate boundary exploration, not just selected settings.
Failed-trial memory may be censored by process death; raw rows retain that flag.
The audit rejects incomplete trials, failed warmups, unexpected HTTP statuses and
non-OOM startup failures. Lost denial replies are not successes or HTTP-clean trials.

## Same-runner comparison with v1.0.2

Candidate and baseline each completed three fresh-pod trials on the same native
runner, at 5 MiB, eight slots/pod and 16 offered requests/pod, using identical caps
and upstream pauses. Candidate ran first, baseline second; this small sequential
comparison is a sanity check, without randomized order or a confidence interval.
No isolated proxy-overhead or broad throughput improvement is inferred.

| Arm | Worst trial success p50 / p95 / p99 ms | Worst rejection p95 ms | Peak RSS / cgroup MiB | Verified 200 / 503 across 3 trials | Errors / OOM / restarts |
| --- | ---: | ---: | ---: | ---: | --- |''']
for a in audit['latency']:
    r=a['trials'];lat={p:max(x['success_latency_ms'][p] for x in r) for p in ['p50','p95','p99']}
    lines.append(f"| {a['arm']} | {timing(lat,1)} | {f(max(x['rejection_latency_ms']['p95'] for x in r))} | {f(max(x['rss_peak_mib'] for x in r))} / {f(max(x['cgroup_peak_mib'] for x in r))} | {sum(x['successes'] for x in r)} / {sum(x['statuses'].get('503',0) for x in r)} | 0 / 0 / 0 |")
for a in audit['latency']:
    p=a['provenance'];lines.append(f"\n- {a['arm']}: {p['preflight']['host'].get('cpu_model') or 'CPU unavailable'}; image reference `{p['image']['reference']}`, resolved ID `{p['image']['id']}`, source `{p['image']['source_commit']}`.")
lines += ['''
The preceding v1.0.2 six-size study was waived and interrupted, so there is no
complete preceding-version resource study to compare. v1.0.1 and older studies
used different hardware, admission behavior and/or sampler methods. Earlier
PR uniform/mixed-body and controlled Responses/LiteLLM studies describe their
named candidate commits; they are not measurements of this final merged runtime.

## Superseded attempts

The first six-size study targeted `dda8c5ddf1b8f9b325087bb9893c839a43fc9d46`.
The 5 MiB job completed but its first Gateway pod restarted before load with a
bootstrap-token store error. A deterministic PostgreSQL integration test reproduced
the same-token unique-prefix race, failed before the fix and passed afterward.
The fix preserves the existing winning token and fails closed when no active token
exists. The report selector was also corrected to prefer repeated stable settings,
and fixture readiness now probes PostgreSQL over TCP.

The other five original searches were cancelled once this runtime fix became
necessary. Their partial/failed checkpoints, the original 5 MiB comparison and
all observations remain in the superseded bootstrap archive. None qualifies this release or
is combined with the final candidate. The second attempt measured `d21547e1b9bff7e4ce9da9810eb099885ef2c7d1`.
Its same-runner comparison completed, but image CI found two newly reported zlib
CVEs in the unchanged pinned base. The actual library was replaced with Debian's
checksum-pinned fixed package. Narrow, versioned scanner exceptions handle the
Debian 13 suite's lack of a fixed-version record and expire on 6 December 2026;
the old image still fails the gate. See [image-security evidence](../runtime-image-security.md#v120-zlib-update).
The six in-progress searches were cancelled and retained in the superseded zlib
archive. All six adaptive searches and the same-runner comparison were freshly
repeated on the final patched image above.

## Verification and retained evidence

The full local verification stack passes, including fmt, Clippy, workspace tests,
539 Nextest cases with no skips, nine vendor tests, audit/deny/machete, Trivy,
Gitleaks and Semgrep. The workspace build, UI build/tests/typecheck/coverage,
29 benchmark harness tests, 12 monitoring fixture tests, strict docs and metadata
validation pass. Final-head CI must also pass the actual production-image checks,
vulnerability gates and continuous ten-minute HTTP/SSE/WebSocket and Usage monitor
before merge. No 24-hour soak is claimed.

A CI Nextest run exposed CPU contention between separate full-cost Argon2 tests:
proof verification exceeded the production one-second deadline. The follow-up
`.config/nextest.toml` reserves the test runner for each authentication unit test.
Their internal concurrency, real hash parameters and all rejection/deadline
assertions remain intact. All 22 authentication tests passed three repeated local
runs (66 executions); the full verification stack was then rerun. This scheduling
file is outside Docker's copied runtime inputs. The measured source, runtime
Dockerfile and benchmark harness are unchanged; equivalence and test evidence
are archived separately.
''',f'''Evidence lives outside the application source tree in the immutable
[v1.2.0 artifact archive](https://github.com/sarattha/relayna-gateway/tree/{archive_commit}).
The docs workflow verifies its SHA-256 manifest before publishing it. The archive
is available before merge; hosted links deploy from main after merge. Release
attachments remain only `CHANGELOG.md` and the SPDX SBOM.

- {link('benchmarks.html','Interactive report')}, {link('benchmarks.json','audited JSON')}, {link('trials.csv','all trial rows CSV')}.
- {link('audit.json','Audit and provenance')}, {link('workflows.json','workflow identities')}, {link('image-security-evidence.tar.gz','image security scans and native smoke evidence')}, {link('verification-evidence.tar.gz','verification and runtime-equivalence evidence')}.
- {link('resource-evidence.tar.gz','Raw resource evidence')}, {link('latency-evidence.tar.gz','same-runner comparison')}, {link('superseded-bootstrap-evidence.tar.gz','superseded bootstrap attempt')}, {link('superseded-zlib-evidence.tar.gz','superseded zlib attempt')}, {link('evidence-SHA256SUMS','checksums')}.

Raw archives include original reports, checkpoints, logs, failed trials, per-pod
memory, hardware/image provenance and exact harness source. Numeric observations
are unchanged. Credentials, kubeconfigs and production prompts are excluded.
The interactive report embeds the licensed Manrope font used by the console.
''']
(repo/'docs/benchmarks/v1.2.0.md').write_text('\n'.join(lines))
